
<div class="wrapper">
    <?php echo $__env->make('includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content_body_admin">
      <a class="btn btn-success pull-right" href="<?php echo e(route('list_sticker')); ?>">Back</a>
      <div class="card mt-5">
        <div class="card-header">Sticker Title</div>
        <div class="card-body"><?php echo e($sticker->name); ?></div> 
        <div class="card-header">Sticker Image</div>
        <div class="card-body">
            <div class="col-md-3">
             <img src="<?php echo e(URL::to($sticker->image)); ?>" class="img img-thumbnail"/>
            </div>
        </div> 
      </div>
    </div>
</div>


<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
       
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\shopifyapp\resources\views/sticker/view.blade.php ENDPATH**/ ?>