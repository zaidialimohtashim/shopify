
<div class="wrapper">
    <?php echo $__env->make('includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content_body_admin">
      <a class="btn btn-success pull-right" href="<?php echo e(route('add_sticker')); ?>">Add Sticker</a>
      <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>File Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php if($stickers->isNotEmpty()): ?>
              <?php $__currentLoopData = $stickers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sticker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($sticker->id); ?></td>
                  <td><?php echo e($sticker->name); ?></td>
                  <td><?php echo e($sticker->filename); ?></td>
                  <td><a href="<?php echo e(route('view_sticker', ['id' => $sticker->id])); ?>"><i class="fa fa-eye"></i></a> &nbsp; <a href="javascript:;" data-id="<?php echo e($sticker->id); ?>" class="delete"><i class="fa fa-trash"></i></a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr style="text-align: center"><td colspan="4">Stickers not found</td></tr>
           <?php endif; ?>
        </tbody>
      </table>
    </div>
</div>


<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(".delete").on('click',function(e){
            var id = $(this).attr('data-id');
            var thats = this;
            var route = "<?php echo e(route('delete_sticker')); ?>";
            $.ajax({
                url: route+'/?id='+id,
                data:{
                  "_token" :"<?php echo e(csrf_token()); ?>",
                },
                type: 'Delete',
                success : function(data) {
                   $(thats).parents('tr').remove();
                }
            });
        });
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\shopifyapp\resources\views/sticker/list.blade.php ENDPATH**/ ?>