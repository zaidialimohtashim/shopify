


<?php $__env->startSection('content'); ?>
<div class="wrapper">
   
    <?php echo $__env->make('product/list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>



    <script>

        actions.TitleBar.create(app, { title: 'Welcome' });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shopifyapp\resources\views//welcome.blade.php ENDPATH**/ ?>