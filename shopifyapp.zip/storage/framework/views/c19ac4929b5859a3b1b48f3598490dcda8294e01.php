



<div class="wrapper">
    <?php echo $__env->make('includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content_body_admin">
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <ul>
                    <li><?php echo \Session::get('success'); ?></li>
                </ul>
            </div>
        <?php endif; ?>
        <a class="btn btn-success pull-right" href="<?php echo e(route('badge_list')); ?>">Back</a>
        <form id="form_add" method="post" action="<?php echo e(route('save_badge')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Badge Title</label>
                    <input type="text" id="name" name="name" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Badge Image</label>
                    <input type="file" id="file" name="file" required class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" value="Add Badge" class="btn btn-primary">
                </div>
            </div>
        </form>
       
      </div>
</div>



<?php $__env->startSection('scripts'); ?>

    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>

    <script>

        // actions.TitleBar.create(app, { title: 'Welcome' });

        $("#form_add").on('submit',function(e){
            var action = $(this).attr("action")
            e.preventDefault();
            var formData = new FormData();
            formData.append("_token", "<?php echo e(csrf_token()); ?>");
            formData.append('file', $('#file')[0].files[0]);
            formData.append('name', $('#name').val());
            $.ajax({
                url: action,
                type: 'POST',
                data: formData,
                async: false,
                cache: false,
                contentType: false,
                enctype: 'multipart/form-data',
                processData: false,
                success : function(data) {
                   $(".alert-success").removeClass('d-none')
                }
            });
        })
        

    </script>

<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\shopifyapp\resources\views/badget/add.blade.php ENDPATH**/ ?>