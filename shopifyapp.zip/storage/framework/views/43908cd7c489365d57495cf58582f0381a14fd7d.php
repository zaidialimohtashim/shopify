<?php echo $__env->make('../includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('../includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="page-wrapper" style="display: block;">
 <div class="page-breadcrumb">
   <div class="row">
       <div class="col-7 align-self-center">
           <h3 class="page-title text-truncate text-dark font-weight-medium mb-1">Shops (Installed App)</h3>
       </div>
   </div>
 </div>
   <div class="container-fluid">
      <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                
            </tr>
        </thead>
        <tbody>
          <?php if($shops->isNotEmpty()): ?>
              <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($shop->id); ?></td>
                  <td><?php echo e($shop->name); ?></td>
                  <td><?php echo e($shop->email); ?></td>
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr style="text-align: center"><td colspan="4">Shops not found</td></tr>
           <?php endif; ?>
        </tbody>
      </table>
    </div>
</div>
<?php echo $__env->make('../includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\shopifyapp\resources\views/shop/list.blade.php ENDPATH**/ ?>