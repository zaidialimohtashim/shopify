<link rel="stylesheet" href="<?php echo e(asset('src/bootstrap.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('src/designerz.css')); ?>"/>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
<script src="<?php echo e(asset('src/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/bootstrap.min.js')); ?>"></script>
<?php /**PATH C:\wamp64\www\shopifyapp\resources\views///includes/sidebar.blade.php ENDPATH**/ ?>