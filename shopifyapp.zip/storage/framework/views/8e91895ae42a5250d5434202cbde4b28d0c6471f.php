<?php echo $__env->make('../includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('../includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="page-wrapper" style="display: block;">
 <div class="page-breadcrumb">
   <div class="row">
       <div class="col-7 align-self-center">
           <h3 class="page-title text-truncate text-dark font-weight-medium mb-1">Customized Products</h3>
       </div>
   </div>
 </div>
   <div class="container-fluid">
          <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Title</th>
                    <th>Description</th>
                    <th>Customize Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
              <?php if($products->isNotEmpty()): ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->product->title); ?></td>
                <td><?php echo e($product->product->description); ?></td>
                <td><a href="<?php echo e(URL::to($product->customize_url)); ?>"  data-lightbox="example-1"><img class="img img-thumbnail" src="<?php echo e(URL::to($product->customize_url)); ?>"/></a></td>
                <td>
                  
                  &nbsp; <a href="javascript:;" title="Delete"  data-toggle="tooltip" data-placement="top" data-id="<?php echo e($product->id); ?>" class="delete"><i class="fa fa-trash"></i></a></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr style="text-align: center"><td colspan="4">Products not found</td></tr>
            <?php endif; ?>
          
          </tbody>
          </table>
         
        </div>
</div>
<?php echo $__env->make('../includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(".delete").on('click',function(e){
            var id = $(this).attr('data-id');
            var thats = this;
            var route = "<?php echo e(route('delete_product')); ?>";
            $.ajax({
                url: route+'/?id='+id,
                data:{
                  "_token" :"<?php echo e(csrf_token()); ?>",
                },
                type: 'Delete',
                success : function(data) {
                   $(thats).parents('tr').remove();
                }
            });
        });

       $(document).ready(function(){
        $('a[data-lightbox]').lightBox({
                          maxHeight: 700, 
                         maxWidth: 700
                    });
                    $('[data-toggle="tooltip"]').tooltip()
       })
      
    </script>

<?php if(config('shopify-app.appbridge_enabled')): ?>
<script type="text/javascript">
    var AppBridge = window['app-bridge'];
    var actions = AppBridge.actions;
    var TitleBar = actions.TitleBar;
    var Button = actions.Button;
    var Redirect = actions.Redirect;
    var titleBarOptions = {
        title: 'Welcome to Tshirt Designer',
    };
    // var myTitleBar = TitleBar.create(app, titleBarOptions);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\shopifyapp\resources\views/product/custom_product_list.blade.php ENDPATH**/ ?>