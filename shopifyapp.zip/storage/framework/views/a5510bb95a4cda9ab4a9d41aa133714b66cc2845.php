
<link rel="stylesheet" href="<?php echo e(asset('src/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('src/designerz.css?v=').uniqid()); ?>" />
<script src="<?php echo e(asset('src/bootstrap.min.js')); ?>"></script>

  <div class="wrapper">
      <div class="content_body">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
              <img src="<?php echo e(asset('src/Logo.png')); ?>" width="30" height="30" class="d-inline-block align-top" alt="">
              Designer
            </a>
          <ul>
              <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li><a href="#">My Products</a></li>
          </ul>
      </nav>
        <?php if($products->isNotEmpty()): ?>
        <div class="row p-3">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card col-md-2 p-3 m-1" style="width: 18rem;">
            <a href="<?php echo e(URL::to('designerz/').'/'.$product->id); ?>"><img class="card-img-top" src="<?php echo URL::to($product->featured_image); ?>" alt="Card image cap"></a>
            
            <div class="card-body">
              <h4 style="font-size: 14px;"><strong><?php echo $product->title; ?></strong></h4>
              <p class="card-text" style="font-size: 14px;">
                <?php echo substr($product->description,0,40)."..."; ?>
              </p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
          <span>Products not found</span>
      <?php endif; ?>

    </div>
</div>


<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(".delete").on('click',function(e){
            var id = $(this).attr('data-id');
            var thats = this;
            var route = "<?php echo e(route('delete_product')); ?>";
            $.ajax({
                url: route+'/?id='+id,
                data:{
                  "_token" :"<?php echo e(csrf_token()); ?>",
                },
                type: 'Delete',
                success : function(data) {
                   $(thats).parents('tr').remove();
                }
            });
        });
     
    </script>

<?php if(config('shopify-app.appbridge_enabled')): ?>
<script type="text/javascript">
    var AppBridge = window['app-bridge'];
    var actions = AppBridge.actions;
    var TitleBar = actions.TitleBar;
    var Button = actions.Button;
    var Redirect = actions.Redirect;
    var titleBarOptions = {
        title: 'Welcome to Tshirt Designer',
    };
    // var myTitleBar = TitleBar.create(app, titleBarOptions);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\shopifyapp\resources\views/product/list.blade.php ENDPATH**/ ?>